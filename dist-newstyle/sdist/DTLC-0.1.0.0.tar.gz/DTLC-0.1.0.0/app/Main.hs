module Main where
import Data
import Eval
import Checker
main :: IO ()
main = putStrLn "Hello, Haskell!"
